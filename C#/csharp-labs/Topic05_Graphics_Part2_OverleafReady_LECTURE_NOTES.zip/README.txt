Overleaf: upload ZIP, compile with pdfLaTeX. Entry: main.tex
