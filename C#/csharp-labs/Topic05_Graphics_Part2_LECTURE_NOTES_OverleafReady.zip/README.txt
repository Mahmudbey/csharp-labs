Overleaf: upload ZIP, set compiler to pdfLaTeX, main file = main.tex
